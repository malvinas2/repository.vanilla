__Skin Titan Vanilla for Kodi Leia__

[Official thread for updates: https://forum.kodi.tv/showthread.php?tid=344342](https://forum.kodi.tv/showthread.php?tid=344342)
