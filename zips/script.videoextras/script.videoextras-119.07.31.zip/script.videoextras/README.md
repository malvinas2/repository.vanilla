__NOTICE__

__I did slight modifications to get this addon running in Kodi Leia 18, but I do not maintain it actively. If you are interested in taking it over then please contact me via the Issues section.__

=== IMPORTANT NOTE === 
At the moment it is just working together with the Titan skin, but not with the default skin, Estuary! 
Up to now I was not able to find out why... 

All credits go to He-who-must-not-be-named aka Robwebset ;-)


![VideoExtras](icon.png)

VideoExtras is an addon that allows you to list and view your DVD or Bluray extras via Kodi.

For more details on how to use VideoExtras please refer to the wiki:

[Add-on:VideoExtras](https://github.com/malvinas2/script.videoextras/wiki)
