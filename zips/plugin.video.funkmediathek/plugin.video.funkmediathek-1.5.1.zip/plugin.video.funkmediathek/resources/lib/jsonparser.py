﻿# -*- coding: utf-8 -*-

import sys
import json
import libmediathek3 as libMediathek
import xbmc
import xbmcplugin
base = 'https://www.funk.net/api/v4.0'

fanart = libMediathek.fanart


#v3.1
#auth = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJjbGllbnROYW1lIjoiY3VyYXRpb24tdG9vbC12Mi4wIiwic2NvcGUiOiJzdGF0aWMtY29udGVudC1hcGksY3VyYXRpb24tc2VydmljZSxzZWFyY2gtYXBpIn0.SGCC1IXHLtZYoo8PvRKlU2gXH1su8YSu47sB3S4iXBI'
#v4.0
auth = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJjbGllbnROYW1lIjoid2ViYXBwLXYzMSIsInNjb3BlIjoic3RhdGljLWNvbnRlbnQtYXBpLGN1cmF0aW9uLWFwaSxuZXh4LWNvbnRlbnQtYXBpLXYzMSx3ZWJhcHAtYXBpIn0.mbuG9wS9Yf5q6PqgR4fiaRFIagiHk9JhwoKES7ksVX4'
header = {'Authorization': auth, 'Accept-Encoding': 'gzip'}


def parseMain():
	xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_LABEL)
	onlySeries = libMediathek.getSetting('skipToSeries') == 'true'
	response = libMediathek.getUrl(base+'/channels/?size=200',header)
	#xbmc.log("[Funkmediathek] parseMain : "+response, xbmc.LOGNOTICE)
	j = json.loads(response)
	l = []
	for item in j['_embedded']['channelDTOList']:
		if item['type'].lower() == 'series' or not onlySeries:
			try:
				d = {}
				d['_name'] = Clean(item['title'])
				if 'shortDescription' in item:
					d['_plot'] = Clean(item['shortDescription'])
				if 'description' in item:
					d['_plot'] = Clean(item['description'])
				if 'imageUrlLandscape' in item:
					d['_thumb'] = item['imageUrlLandscape']
				if 'imageUrlSquare' in item:
					d['_thumb'] = item['imageUrlSquare']
				if 'imageUrlOrigin' in item:
					d['_fanart'] = item['imageUrlOrigin']
				d['_type'] = 'dir'
				d['id'] = item['alias']
				if item['type'].lower() == 'series':
					d['mode'] = 'listSeasons'
				elif 'format' in item['type'].lower():
					d['mode'] = 'listVideos'
				l.append(d)
			except:
				libMediathek.log(json.dumps(item))
	return l

def parseSeasons(id):
	# https://www.funk.net/api/v4.0/playlists/byChannelAlias/alles-liebe-annette?sort=language,asc
	response = libMediathek.getUrl(base+'/playlists/byChannelAlias/'+id+'?sort=language,asc',header)
	#xbmc.log("[Funkmediathek] parseSeasons : "+response, xbmc.LOGNOTICE)
	j = json.loads(response)
	l = []
	for item in j['_embedded']['playlistDTOList']:
		d = {}
		d['_name'] = Clean(item['title'])
		if 'shortDescription' in item:
			d['_plot'] = Clean(item['shortDescription'])
		if 'description' in item:
			d['_plot'] = Clean(item['description'])
		if 'imageUrlPortrait' in item:
			d['_thumb'] = item['imageUrlPortrait']
		else:
			if 'imageUrlSquare' in j['parent']:
				d['_thumb'] = j['parent']['imageUrlSquare']
		if 'imageUrlLandscape' in item:
			d['_fanart'] = item['imageUrlLandscape']
		else:
			if 'imageUrlLandscape' in j['parent']:
				d['_fanart'] = j['parent']['imageUrlLandscape']
		d['_type'] = 'season'
		d['id'] = item['alias']
		d['mode'] = 'listEpisodes'
		l.append(d)
	return l

def parseEpisodes(id):
	# https://www.funk.net/api/v4.0/videos/byPlaylistAlias/alles-liebe-annette-staffel-1?filterFsk=false&size=100&sort=episodeNr,asc
	response = libMediathek.getUrl(base+'/videos/byPlaylistAlias/'+id+'?filterFsk=false&size=100&sort=episodeNr,asc',header)
	#xbmc.log("[Funkmediathek] parseEpisodes : "+response, xbmc.LOGNOTICE)
	j = json.loads(response)
	l = []
	for item in j['_embedded']['videoDTOList']:
		d = {}
		d['_name'] = Clean(item['title'])
		if 'title' in j['parent']:
			d['_tvshowtitle'] = Clean(j['parent']['title'])
		if 'shortDescription' in item:
			d['_plot'] = Clean(item['shortDescription'])
		if 'description' in item:
			d['_plot'] = Clean(item['description'])
		if 'imageUrlSquare' in item:
			d['_thumb'] = item['imageUrlSquare']
		if 'imageUrlLandscape' in item:
			d['_thumb'] = item['imageUrlLandscape']
		if 'imageUrlOrigin' in item:
			d['_fanart'] = item['imageUrlOrigin']
		if 'fsk' in item:
			d['_mpaa'] = 'FSK '+str(item['fsk'])
		if 'seasonNr' in item:
			d['_season'] = str(item['seasonNr'])
		if 'episodeNr' in item:
			d['_episode'] = str(item['episodeNr'])
		d['_duration'] = item['duration']
		d['_type'] = 'episode'
		d['sourceId'] = str(item['entityId'])
		d['mode'] = 'play'
		l.append(d)
	return l

def parseVideos(id):
	# https://www.funk.net/api/v4.0/videos/byChannelAlias/auf-einen-kaffee-mit-moritz-neumeier?filterFsk=false&page=0&size=100&sort=creationDate,desc
	if id[:4] == "http":
		response = libMediathek.getUrl(id,header)
	else:
		response = libMediathek.getUrl(base+'/videos/byChannelAlias/'+id+'?filterFsk=false&page=0&size=50&sort=creationDate,desc',header)
	#xbmc.log("[Funkmediathek] parseVideos : "+response, xbmc.LOGNOTICE)
	j = json.loads(response)
	l = []
	for item in j['_embedded']['videoDTOList']:
		d = {}
		d['_name'] = Clean(item['title'])
		if 'shortDescription' in item:
			d['_plot'] = Clean(item['shortDescription'])
		if 'description' in item:
			d['_plot'] = Clean(item['description'])
		if 'imageUrlSquare' in item:
			d['_thumb'] = item['imageUrlSquare']
		if 'imageUrlLandscape' in item:
			d['_thumb'] = item['imageUrlLandscape']
		if 'imageUrlOrigin' in j['parent']:
			d['_fanart'] = j['parent']['imageUrlOrigin']
		if 'fsk' in item:
			d['_mpaa'] = 'FSK '+str(item['fsk'])
		d['_duration'] = item['duration']
		d['_type'] = 'video'
		d['sourceId'] = str(item['entityId'])
		d['mode'] = 'play'
		l.append(d)
	if 'next' in j['_links'] and 'href' in j['_links']['next'] and j['_links']['next']['href'][:4] == "http":
		d = {} # https://www.funk.net/v4.0/videos/byChannelAlias/das-schaffst-du-nie-1423?page=1&size=100&sort=creationDate,desc
		d['id'] = j['_links']['next']['href'].replace('https://www.funk.net/v4.0', base)
		d['type'] = 'nextPage'
		d['mode'] = 'listVideos'
		l.append(d)
	return l

def Clean(string):
	for n in (('&lt;', '<'), ('&gt;', '>'), ('&amp;', '&'), ('&apos;', "'"), ("&#x27;", "'"), ('&#34;', '"'), ('&#39;', '\''), ('&#039;', '\''), ('►', '>')
		, ('&#x00c4', 'Ä'), ('&#x00e4', 'ä'), ('&#x00d6', 'Ö'), ('&#x00f6', 'ö'), ('&#x00dc', 'Ü'), ('&#x00fc', 'ü'), ('&#x00df', 'ß'), ('&#xD;', ''), ('\xc2\xb7', '-')
		, ('&quot;', '"'), ('&szlig;', 'ß'), ('&ndash;', '-'), ('&Auml;', 'Ä'), ('&Ouml;', 'Ö'), ('&Uuml;', 'Ü'), ('&auml;', 'ä'), ('&ouml;', 'ö'), ('&uuml;', 'ü')
		, ('&agrave;', 'à'), ('&aacute;', 'á'), ('&acirc;', 'â'), ('&egrave;', 'è'), ('&eacute;', 'é'), ('&ecirc;', 'ê'), ('&igrave;', 'ì'), ('&iacute;', 'í'), ('&icirc;', 'î')
		, ('&ograve;', 'ò'), ('&oacute;', 'ó'), ('&ocirc;', 'ô'), ('&ugrave;', 'ù'), ('&uacute;', 'ú'), ('&ucirc;', 'û')):
		string = string.replace(*n)
	return string
