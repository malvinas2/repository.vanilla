__NOTICE__

__It did a slight modification to get this addon running in Kodi Leia 18, but I do not maintain it actively. If you are interested in taking it over then please contact me via the Issues section.__

All credits go to He-who-must-not-be-named aka Robwebset ;-)


![TvTunes](icon.png)

TvTunes has grown over time and is now more than a simple theme player for TV Shows, some of the features include:
* Play themes while navigating TV Shows
* Play themes while navigating Movies
* Play themes while navigating Music Videos
* Download themes from a selection of differrent websites
* Play video themes in addition to audio themes
* Screensaver that plays the themes and shows fanart, cast and thumbnails (See: [TvTunesScreensaver](https://github.com/robwebset/screensaver.tvtunes))

It is a feature rich and very configurable addon with numerous settings to allow you to fine-tune it to your own requirements.

More details, and how to use the addon can be viewed on the wiki:

[Add-on:TvTunes](https://github.com/malvinas2/script.tvtunes/wiki)

