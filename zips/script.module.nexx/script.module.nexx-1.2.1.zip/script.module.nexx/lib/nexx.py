﻿# -*- coding: utf-8 -*-

import libmediathek3 as libmediathek
import json
import xbmc

#needs:
#operations = {}, hashes of possible operations
#channelId = '', channel id, 3 digets
#origin = '', base url of the website

#optional:
#blacklist = [], blacklists directory ids

base = 'https://api.nexx.cloud/v3/'
additional = '?limit=100&additionalfields=all'
blacklist = []
path = False


#depricated functions
def listDir():
	return getDir()
def listVideos():
	return getVideos()


def getDir():
	cid = _initSession()
	response = libmediathek.getUrl(base + channelId + '/' + streamtype + '/all' + additional, _header('all',cid))
	j = json.loads(response)
	l = []
	for item in j['result']:
		d = _grepMetadata(item)
		d['_type'] = 'dir'
		d['mode'] = 'listVideos'
		d['streamtype'] = 'videos'
		d['operation'] = streamtype2operation[streamtype]
		if not d['id'] in blacklist:
			l.append(d)
	return l

def getVideos():
	cid = _initSession()
	if path:
		response = libmediathek.getUrl(base + channelId + path + additional, _header(operation,cid))
	else:
		response = libmediathek.getUrl(base + channelId + '/' + streamtype + '/' + operation + '/' + id + additional, _header(operation,cid))
	j = json.loads(response)
	items = j['result']
	l = []
	for item in items:
		d = _grepMetadata(item)
		d['_type'] = 'episode'
		d['mode'] = 'play'
		l.append(d)
	return l

def getVideoUrl(id):
	cid = _initSession()
	response = libmediathek.getUrl(base + channelId + '/videos/byid/' + id + '?additionalfields=language%2Cchannel%2Cformat%2Cpersons%2Cstudio%2Clicenseby%2Cslug%2Cfileversion%2CcontentModerationAspects%2Cpodcast_url%2Csubtitle%2Cteaser%2Cdescription%2Creleasedate&addInteractionOptions=1&addStatusDetails=1&addStreamDetails=1&addFeatures=1&addCaptions=1&addScenes=1&addChapters=1&addHotSpots=1&addBumpers=1&captionFormat=data&addItemData=1&addPodcastDetails=1',_header('byid',cid))
	#response = libmediathek.getUrl(base + channelId + '/videos/byid/' + id + '?additionalfields=language%2Cchannel%2Cactors%2Cstudio%2Clicenseby%2Cslug%2Cfileversion%2Csubtitle%2Cteaser%2Cdescription%2Creleasedate&addInteractionOptions=1&addStatusDetails=1&addStreamDetails=1&addFeatures=1&addCaptions=1&addScenes=1&addHotSpots=1&addBumpers=1&captionFormat=data',_header('byid',cid))
	libmediathek.log(response)
	js = json.loads(response)
	Stream = False
	cdn_type = js['result']['streamdata']['cdnType']
	if cdn_type == 'azure':
		ret = 2
		secret = ""
		if "token" in js['result']['protectiondata'] and js['result']['protectiondata']['token'] != "":
			secret = "?hdnts="+js['result']['protectiondata']['token']
		if "tokenHLS" in js['result']['protectiondata'] and js['result']['protectiondata']['tokenHLS'] != "":
			secretHLS = "?hdnts="+js['result']['protectiondata']['tokenHLS']
		else:
			secretHLS = secret
		if "tokenDASH" in js['result']['protectiondata'] and js['result']['protectiondata']['tokenDASH'] != "":
			secretDASH = "?hdnts="+js['result']['protectiondata']['tokenDASH']
		else:
			secretDASH = secret
		HLS  = 'http://'+js['result']['streamdata']['cdnShieldHTTP']+js['result']['streamdata']['azureLocator']+'/'+str(js['result']['general']['ID'])+'_src.ism/Manifest(format=m3u8-aapl)'+secretHLS
		DASH = 'http://'+js['result']['streamdata']['cdnShieldHTTP']+js['result']['streamdata']['azureLocator']+'/'+str(js['result']['general']['ID'])+'_src.ism/Manifest(format=mpd-time-csf)'+secretDASH
	elif cdn_type == 'free':
		ret,Stream = _extractFree(js, id)
	# http://vcdn.hls.spiegel.de/748/47/53/1633574/asset.ism/manifest.mpd?dcp_ver=aos4&videostream=1633574OW5D2FXH_320x180_400.mp4:400000,1633574OW5D2FXH_640x360_700.mp4:700000,1633574OW5D2FXH_720x404_900.mp4:900000,1633574OW5D2FXH_1024x576_1500.mp4:1500000,1633574OW5D2FXH_1280x720_2500.mp4:2500000&audiostream=1633574OW5D2FXH_1280x720_2500.mp4
	# http://vcdn.hls.spiegel.de/748/96/68/128669/asset.ism/asset-audio=666666-video=2500000.m3u8?dcp_ver=aos4&videostream=TR3128669ZDCK8B_320x180_400.mp4:400000,TR3128669ZDCK8B_640x360_650.mp4:650000,TR3128669ZDCK8B_720x404_900.mp4:900000,TR3128669ZDCK8B_960x540_1500.mp4:1500000,TR3128669ZDCK8B_1280x720_2500.mp4:2500000&audiostream=TR3128669ZDCK8B_1280x720_2500.mp4&AliasPass=vcdn.hls.spiegel.de
	d = {}
	d['media'] = []
	if ret == 1:
		if Stream:
			HLS = Stream
		d['media'].append({'url': HLS, 'type': 'video', 'stream': 'HLS'})
	else:
		if Stream:
			DASH = Stream
		d['media'].append({'url': DASH, 'type': 'video', 'stream': 'DASH'})
	return d

def _extractFree(js, id):
	hash = js['result']['general']['hash']
	stream_data = js['result']['streamdata']
	cdn_type = stream_data['cdnType']
	cdn_provider = stream_data['cdnProvider']
	aFD = stream_data['azureFileDistribution'].split(',')
	com = str(stream_data['originalDomain'])
	if stream_data['applyFolderHierarchy'] == 1:
		s = ('%04d' % int(id))[::-1]
		com += '/%s/%s' % (s[0:2], s[2:4])
	com += '/%s/%s_' % (id, hash)
	ret = 0

	def p0(p):
		return '_%s' % p if stream_data['applyAzureStructure'] == 1 else ''

	if cdn_provider == 'ak':
		ret = 1
		start = 'http://'+stream_data['cdnPathHLS']
		com += ','
		for i in aFD:
			p = i.split(':')
			com += p[1] + p0(int(p[0])) + ','
		com += '.mp4.csmil/master.m3u8'
	elif cdn_provider == 'ce':
		ret = 2
		start = 'http://'+stream_data['cdnPathDASH']
		k = com.split('/')
		h = k.pop()
		http_base = com = '/'.join(k)
		com += '/asset.ism/manifest.mpd?dcp_ver=aos4&videostream='
		for i in aFD:
			p = i.split(':')
			tbr = int(p[0])
			filename = '%s%s%s.mp4' %(h, p[1], p0(tbr))
			a = filename+':'+str(int(tbr)*1000)
			com += a+','
		com = com[:-1]+'&audiostream='+a.split(':')[0]
	return ret,start+com

def _initSession():
	response = libmediathek.getUrl(base + channelId + '/session/init?nxp_devh=4"%"3A1500496747"%"3A178989',_header())
	js = json.loads(response)
	return js['result']['general']['cid']

def _grepMetadata(j):
	d = {}
	d['id'] = str(j['general']['ID'])
	d['_name'] = j['general']['title']
	d['_tvshowtitle'] = j['general']['subtitle']
	d['_epoch'] = str(j['general']['updated'])
	if 'runtime' in j['general'] and j['general']['runtime'] != '':
		HH,MM,SS = j['general']['runtime'].split(':')
		d['duration'] = str(int(HH)*3600+int(MM)*60+int(SS))
	if 'studio_adref' in j['general'] and j['general']['studio_adref'] != '':
		d['channel'] = j['general']['studio_adref']
	if 'teaser' in j['general'] and j['general']['teaser'] != '':
		d['_plotoutline'] = j['general']['teaser']
	if 'textcontent' in j['general'] and j['general']['textcontent'] != '':
		d['_plot'] = j['general']['textcontent']
	elif 'description' in j['general'] and j['general']['description'] != '':
		d['_plot'] = j['general']['description']
	if 'thumb' in j['imagedata'] and j['imagedata']['thumb'] != '':
		d['_thumb'] = j['imagedata']['thumb']
	if 'thumb_action' in j['imagedata'] and j['imagedata']['thumb_action'] != '':
		d['_fanart'] = j['imagedata']['thumb_action']
	return d

def _header(operation=False,c=False):
	header = {}
	header['Accept'] = '*/*'
	header['User-Agent'] = 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:60.0) Gecko/20100101 Firefox/60.0'
	header['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
	header['Accept-Encoding'] = 'gzip, deflate'
	header['Host'] = 'api.nexx.cloud'
	if operation:
		header['Origin'] = origin
		if not c:
			c = cid
		header['X-Request-CID'] = c
		header['X-Request-Token'] = operations[operation]
	else:
		header['X-Request-Enable-Auth-Fallback'] = '1'
	return header
